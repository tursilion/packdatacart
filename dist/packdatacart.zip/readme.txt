Quick and dirty tool to pack data into a TI cartridge

packdatacart <outfile> <program> <data1> <data2> <data3> ...

Program first ensures that the program is padded to 8k (warn if bigger).

For each datafile in the list:
-Report the address and the bank switch for it
-for each 8k page, copy the first 128 bytes of the program, then 8192-128 bytes of the data
-pad the last block of each file to 8k, no sharing
-after the last file, report the next free page

For now, assumes your program is 8k and that the startup code (which MUST start
with an instruction to switch in the first cartridge bank) is in the first
128 bytes. These 128 bytes are copied to every bank to guarantee startup.

Creates non-inverted carts for now
